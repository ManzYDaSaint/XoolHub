const router = require('express').Router();
const performanceMonitor = require('../utils/performanceMonitor');
const { cache } = require('../database/fileCache.js');
const realTimeCacheService = require('../services/realTimeCache.js');
const { sessionStatsMiddleware, sessionHealthCheck } = require('../middleware/session.js');
// Input validation middleware removed
const { ipRateLimit, emailRateLimit } = require('../middleware/security.js');
const { 
    signup, 
    login, 
    verifyOTP, 
    resendOTP,
    createResetSession, 
    resetPassword, 
    addExam, 
    getExams, 
    deleteExams,
    updateExams, 
    editExams,
    addYear,
    getYears,
    deleteYears,
    editYears,
    updateYears,
    addSubject,
    getSubjects,
    deleteSubjects,
    editSubjects,
    updateSubjects,
    verify,
    Logout,
    addClass,
    getClasses,
    deleteClasses,
    editClasses,
    updateClasses,
    addTerm,
    getTerms,
    deleteTerms,
    editTerms,
    updateTerms,
    addGrade,
    getGrades,
    deleteGrades,
    editGrades,
    updateGrades,
    addJCE,
    getJCEs,
    deleteJCEs,
    editJCEs,
    updateJCEs,
    addMSCE,
    getMSCEs,
    deleteMSCEs,
    editMSCEs,
    updateMSCEs,
    addTeacher,
    getTeachers,
    deleteTeachers,
    editTeachers,
    updateTeachers,
    addAssignTeacher,
    getAssignTeachers,
    deleteAssignTeachers,
    addClassTeacher,
    getClassTeachers,
    deleteClassTeachers,
    getSingleTeachers,
    getTeacherClasses,
    getTeacherSubjects,
    addStudent,
    getStudents,
    deleteStudents,
    getSingleStudents,
    updateStudents,
    addFee,
    getFees,
    deleteFees,
    editFees,
    updateFees,
    getPays,
    getPayees,
    addPay,
    editPays,
    updatePays,
    deletePays,
    tverify,
    getClassesTeacher,
    getSubjectsTeacher,
    getExamsTeacher,
    getTermsTeacher,
    getYearsTeacher,
    getStudentFilter,
    insertResults,
    getXs,
    getScores,
    updateScores,
    getClassStudents,
    getSingleStud,
    getFinancial,
    getSingleTeacher4Dashboard,
    getClassNSubjects,
    dashboardClassTeachers,
    getGenderPieTeacher,
    getTopStudents,
    getAverageScoreBySubject,
    countStudentByTeacher,
    getSchool,
    updateSchools,
    getReport,
    getStudentReport,
    getCT4Report,
    getCount,
    getSubjectPos,
    realPosition,
    getTByS,
    getRemarksByClassID,
    getJCEGrades,
    getMSCEGrades,
    deleteReports,
    deleteResults,
    StudentCounter,
    countMales,
    countFemales,
    countGenderForClass,
    genderByPercentage,
    TeacherCounter,
    countMalesTeacher,
    countFemalesTeacher,
    genderTeacherPercentage,
    sumPayments,
    sumPayDisMonth,
    getTuitions,
    getOutstandings,
    PaidByDaysPerTerm,
    PaidByClasses,
    countTermlyReports,
    PasswordUpdates,
    superVerify,
    PasswordSuper,
    countXuls,
    getXuls,
    addSubscriptions,
    gotSubscriptions,
    getPublicPricingPlans,
    deletePlan,
    editPlans,
    updatePlans,
    gotSubs,
    insertSubscription,
    checkSubStatus,
    checkPaidStatus,
    updateSuspended,
    gotSubscriptionPayments,
    updateStatuses,
    updateSchoolStatuses,
    getRealTimePaymentStatus,
    countPrivateXuls,
    countPublicXuls,
    countSubscribedXuls,
    sumAmounts,
    paymentLineChart,
    insertEvent,
    getEvent,
    editEvents,
    updateEvents,
    deleteEvents,
    insertPromotion,
    getStudentPromos,
    updatePromotions,
    getBestStudents,
    getWorstStudents,
    avSubjectbyClassID,
    TeacherPasswordUpdates,
    addSubscriber,
    insertFeedback,
    getFeedbacko,
    getFeedbackRating,
    SubsByID,
    countOTeachers,
    countOStudents,
    getAdministrator,
    updateAdministrator,
    insertContacts,
    tsumPayments,
    gettOutstandings,
    gettTuitions,
    sumtPayDisMonth,
    tStudentCounter,
    gettPays,
    gettFees,
    gettStudents,
    insertExpense,
    getExpenses,
    editExpenses,
    updateExpenses,
    deleteExpenses,
    sumExpenses,
    countExpenses,
    AvgMonthly,
    Transactions,
    getChartLiner,
    getAdminExpenses,
    updateStatusEx,
    cancSubscription,
    insertAttendance,
    addDisciplinary,
    getDisciplinary,
    getDisciplinaryById,
    updateDisciplinary,
    deleteDisciplinary,
    getDisciplinaryStats,
    getParentBotStats,
    getParentBotFeedbackBySchool,
    getParentBotRealTimeStats,
    getParentBotNotifications,
    // Referral system imports
    // createReferralCode,
    // getReferralCode,
    // validateReferralCode,
    // trackReferralUsage,
    // getReferralAnalytics,
    // getAllReferralAnalytics,
    // getReferralTracking,
    // applyReferralDiscount,
    // getReferralSettings,
    // updateReferralSettings,
    gotStudents,
    gotCountry,
} = require('../controller/apiController.js');



// ------- ATTENDANCE ROUTES -----------
router.route('/insert-attendance').post(insertAttendance);
// ------- ATTENDANCE ROUTES -----------


router.route('/count-schools').get(countXuls);
router.route('/count-o-teachers').get(countOTeachers);
router.route('/count-o-students').get(countOStudents);
router.route('/count-private-schools').get(countPrivateXuls);
router.route('/count-public-schools').get(countPublicXuls);
router.route('/count-subscribed').get(countSubscribedXuls);
router.route('/sum-amount').get(sumAmounts);
router.route('/get-schools').get(getXuls);
router.route('/payment-linechart').get(paymentLineChart);

// ***** POST Methods
// router.route('/authenticate').post((req, res) => res.end());


// ***** GET Methods
router.route('/verifyOTP').post(verifyOTP);
router.route('/resendOTP').post(resendOTP);
router.route('/forgot-password').post(emailRateLimit, createResetSession);
router.route('/reset-password').post(emailRateLimit, resetPassword);

// Security monitoring routes
const {
  getSecurityDashboard,
  getSecurityAlerts,
  getPasswordResetAnalytics,
  getSecurityIncidents,
  blockSuspiciousIP,
  exportSecurityData
} = require('../controller/securityController');

router.route('/security/dashboard').get(getSecurityDashboard);
router.route('/security/alerts').get(getSecurityAlerts);
router.route('/security/analytics').get(getPasswordResetAnalytics);
router.route('/security/incidents').get(getSecurityIncidents);
router.route('/security/block-ip').post(blockSuspiciousIP);
router.route('/security/export').get(exportSecurityData);



// ------- SUPER ADMIN ROUTES -----------

router.route('/add-subscriptions').post(addSubscriptions);
router.route('/get-subscriptions').get(gotSubscriptions);
router.route('/public-pricing-plans').get(getPublicPricingPlans);
router.route('/delete-subscriptions/:id').delete(deletePlan);
router.route('/edit-subscriptions/:id').get(editPlans);
router.route('/update-subscriptions/:id').put(updatePlans);

// ------- SUPER ADMIN ROUTES -----------




// ------- SUBSCRIPTION ROUTES -----------

router.route('/got-subscription/:plan').get(gotSubs);
router.route('/get-subs').get(SubsByID);
router.route('/add-billing').post(insertSubscription);
router.route('/check-subscription-status').get(checkSubStatus);
router.route('/check-paid-status').get(checkPaidStatus);
router.route('/update-suspended-status').put(updateSuspended);
router.route('/cancel-subscription').put(cancSubscription);
router.route('/get-subscription-payments').get(gotSubscriptionPayments);
router.route('/update-statuses/:id').put(updateStatuses);
router.route('/update-school-status/:id').put(updateSchoolStatuses);
router.route('/real-time-payment-status').get(getRealTimePaymentStatus);

// ------- SUBSCRIPTION ROUTES -----------





// ------- REGISTER ROUTES -----------
router.route('/signup').post(ipRateLimit, signup)
router.route('/updateschool').put(updateSchools);
router.route('/update-school-password').put(PasswordUpdates);
router.route('/update-teacher-password').put(TeacherPasswordUpdates);
router.route('/update-super-password').put(PasswordSuper);
router.route('/get-administrator').get(getAdministrator);
router.route('/update-administrator').put(updateAdministrator);
// ------- REGISTER ROUTES -----------



// ------- CONTACTS ROUTES -----------
router.route('/add-contacts').post(insertContacts);
// ------- CONTACTS ROUTES -----------




// ------- LOGIN ROUTES -----------

router.route('/login').post(ipRateLimit, login);
router.route('/verify').post(verify);
router.route('/tverify').post(tverify);
router.route('/superverify').post(superVerify);
router.route('/logout').post(Logout);

// ------- LOGIN ROUTES -----------




// ------- EXAM ROUTES -----------

router.route('/addexam').post(addExam);
router.route('/getexam').get(getExams);
router.route('/deletexam/:id').delete(deleteExams);
router.route('/editexam/:id').get(editExams);
router.route('/updatexam/:id').put(updateExams);

// ------- EXAM ROUTES ----------- 



// ------- YEAR ROUTES -----------

router.route('/addyear').post(addYear);
router.route('/getyear').get(getYears);
router.route('/deletyear/:id').delete(deleteYears);
router.route('/edityear/:id').get(editYears);
router.route('/updatyear/:id').put(updateYears);

// ------- YEAR ROUTES ----------- 



// ------- SUBJECT ROUTES -----------

router.route('/addsubject').post(addSubject);
router.route('/getsubject').get(getSubjects);
router.route('/deletsubject/:id').delete(deleteSubjects);
router.route('/editsubject/:id').get(editSubjects);
router.route('/updatsubject/:id').put(updateSubjects);

// ------- SUBJECT ROUTES ----------- 




// ------- CLASS ROUTES -----------

router.route('/addclass').post(addClass);
router.route('/getclass').get(getClasses);
router.route('/deletclass/:id').delete(deleteClasses);
router.route('/editclass/:id').get(editClasses);
router.route('/updatclass/:id').put(updateClasses);

// ------- CLASS ROUTES ----------- 



// ------- TERM ROUTES -----------

router.route('/addterm').post(addTerm);
router.route('/getterm').get(getTerms);
router.route('/deletterm/:id').delete(deleteTerms);
router.route('/editterm/:id').get(editTerms);
router.route('/updatterm/:id').put(updateTerms);

// ------- TERM ROUTES ----------- 



// ------- GRADE ROUTES -----------

router.route('/addgrade').post(addGrade);
router.route('/getgrade').get(getGrades);
router.route('/getjcegrade').get(getJCEGrades);
router.route('/getmscegrade').get(getMSCEGrades);
router.route('/deletgrade/:id').delete(deleteGrades);
router.route('/editgrade/:id').get(editGrades);
router.route('/updatgrade/:id').put(updateGrades);

// ------- GRADE ROUTES ----------- 




// ------- JCE ROUTES -----------

router.route('/addjce').post(addJCE);
router.route('/getjce').get(getJCEs);
router.route('/deletjce/:id').delete(deleteJCEs);
router.route('/editjce/:id').get(editJCEs);
router.route('/updatjce/:id').put(updateJCEs);

// ------- JCE ROUTES ----------- 




// ------- MSCE ROUTES -----------

router.route('/addmsce').post(addMSCE);
router.route('/getmsce').get(getMSCEs);
router.route('/deletmsce/:id').delete(deleteMSCEs);
router.route('/editmsce/:id').get(editMSCEs);
router.route('/updatmsce/:id').put(updateMSCEs);

// ------- MSCE ROUTES ----------- 




// ------- TEACHER ROUTES -----------

router.route('/addteacher').post(addTeacher);
router.route('/getteacher').get(getTeachers);
router.route('/getsingleteacher/:id').get(getSingleTeachers);
router.route('/getteacherclasses/:id').get(getTeacherClasses);
router.route('/getteachersubjects/:id').get(getTeacherSubjects);
router.route('/deletteacher/:id').delete(deleteTeachers);
router.route('/editteacher/:id').get(editTeachers);
router.route('/updatteacher/:id').put(updateTeachers);
router.route('/count-teachers').get(TeacherCounter);
router.route('/count-male-teachers').get(countMalesTeacher);
router.route('/count-female-teachers').get(countFemalesTeacher);
router.route('/gender-percentage-teachers').get(genderTeacherPercentage);

// ------- TEACHER ROUTES ----------- 



// ------- ASSIGN TEACHER ROUTES -----------

router.route('/addassignteacher').post(addAssignTeacher);
router.route('/getassignteacher').get(getAssignTeachers);
router.route('/deletassignteacher/:id').delete(deleteAssignTeachers);

// ------- ASSIGN TEACHER ROUTES ----------- 




// ------- CLASS TEACHER ROUTES -----------

router.route('/addclassteacher').post(addClassTeacher);
router.route('/getclassteacher').get(getClassTeachers);
router.route('/deletclassteacher/:id').delete(deleteClassTeachers);

// ------- CLASS TEACHER ROUTES ----------- 




// ------- STUDENT ROUTES -----------

router.route('/addstudent').post(addStudent);
router.route('/getstudent').get(getStudents);
router.route('/gettstudent').get(gettStudents);
router.route('/count-student').get(StudentCounter);
router.route('/countt-student').get(tStudentCounter);
router.route('/count-male').get(countMales);
router.route('/count-female').get(countFemales);
router.route('/count-gender-class').get(countGenderForClass);
router.route('/gender-percentage').get(genderByPercentage);
router.route('/getsinglestudent/:id').get(getSingleStudents);
router.route('/deletstudent/:id').delete(deleteStudents);
router.route('/updatstudent/:id').put(updateStudents);
router.route('/stat-students').get(gotStudents);
router.route('/stat-country').get(gotCountry);

// ------- STUDENT ROUTES ----------- 





// ------- FEE ROUTES -----------

router.route('/addfee').post(addFee);
router.route('/getfee').get(getFees);
router.route('/gettfee').get(gettFees);
router.route('/deletfee/:id').delete(deleteFees);
router.route('/editfee/:id').get(editFees);
router.route('/updatfee/:id').put(updateFees);

// ------- FEE ROUTES ----------- 




// ------- PAYMENT ROUTES ----------- 

router.route('/getpay').get(getPays);
router.route('/gettpay').get(gettPays);
router.route('/getpayee/:id').get(getPayees);
router.route('/addpay').post(addPay);
router.route('/editpay/:id').get(editPays);
router.route('/updatpay/:id').put(updatePays);
router.route('/deletpay/:id').delete(deletePays);
router.route('/count-payments').get(sumPayments);
router.route('/count-tpayments').get(tsumPayments);
router.route('/count-payment-month').get(sumPayDisMonth);
router.route('/countt-payment-month').get(sumtPayDisMonth);
router.route('/get-tuition').get(getTuitions);
router.route('/gett-tuition').get(gettTuitions);
router.route('/get-outstanding').get(getOutstandings);
router.route('/gett-outstanding').get(gettOutstandings);
router.route('/payment-days').get(PaidByDaysPerTerm);
router.route('/payment-classes').get(PaidByClasses);

// ------- PAYMENT ROUTES ----------- 




// ------- ENTRY ROUTES ----------- 
router.route('/getassignedclass').get(getClassesTeacher);
router.route('/getassignedsubject/:id').get(getSubjectsTeacher);
router.route('/getassignedexam').get(getExamsTeacher);
router.route('/getassignedterm').get(getTermsTeacher);
router.route('/getassignedyear').get(getYearsTeacher);
router.route('/getstudentfilter').post(getStudentFilter);
router.route('/insertresults').post(insertResults);
// ------- ENTRY ROUTES -----------




// ------- FILTER ROUTES -----------
router.route('/getx').post(getXs);
router.route('/deleteresult').delete(deleteResults);
router.route('/getscore/:id').get(getScores);
router.route('/updatscore/:id').put(updateScores);
// ------- FILTER ROUTES -----------




// ------- TEACHER STUDENNT ROUTES -----------
router.route('/getcs').get(getClassStudents);
router.route('/getsinglestud/:id').get(getSingleStud);
router.route('/getfin/:id').get(getFinancial);
// ------- TEACHER STUDENNT ROUTES -----------



// ------- TEACHER DASHBOARD ROUTES -----------
router.route('/getstd').get(getSingleTeacher4Dashboard);
router.route('/getcns').get(getClassNSubjects);
router.route('/getdct').get(dashboardClassTeachers);
// ------- TEACHER DASHBOARD ROUTES -----------




// ------- CHART ROUTES -----------
router.route('/getstudentgender/:id').get(getGenderPieTeacher);
router.route('/gettopstudent').get(getTopStudents);
router.route('/getavesubject').get(getAverageScoreBySubject);
router.route('/countstudentteacher').get(countStudentByTeacher);
// ------- CHART ROUTES -----------





// ------- ADMIN PROFILE ROUTES -----------
router.route('/admindet').get(getSchool);
// ------- ADMIN PROFILE ROUTES -----------



// ------- REPORT ROUTES -----------
// JCE
router.route('/getreport').post(getReport);
router.route('/insert-promotion').post(insertPromotion);
router.route('/get-student-promotion').post(getStudentPromos);
router.route('/update-pro').post(updatePromotions);
router.route('/best-students').get(getBestStudents);
router.route('/average-subject').post(avSubjectbyClassID);
router.route('/worst-students').get(getWorstStudents);
router.route('/getstudentreport').post(getStudentReport);
router.route('/getctreport').post(getCT4Report);
router.route('/countreport').post(getCount);
router.route('/subjectpos').post(getSubjectPos);
router.route('/realpos').post(realPosition);
router.route('/gettbs').post(getTByS);
router.route('/getremarkbyclass').post(getRemarksByClassID);
router.route('/deletereport').delete(deleteReports);
router.route('/count-reports').get(countTermlyReports);
// JCE
// ------- REPORT ROUTES -----------



// ------- EVENTS ROUTES -----------
router.route('/insert-event').post(insertEvent);
router.route('/get-event').get(getEvent);
router.route('/edit-event/:id').get(editEvents);
router.route('/update-event/:id').put(updateEvents);
router.route('/delete-event/:id').delete(deleteEvents);
// ------- EVENTS ROUTES -----------



// ------- SUBSCRIBE ROUTES -----------
router.route('/insert-subscribe').post(addSubscriber);
// ------- SUBSCRIBE ROUTES -----------



// ------- FEEDBACK ROUTES -----------
router.route('/insert-feedback').post(insertFeedback);
router.route('/get-feedback').get(getFeedbacko);
router.route('/get-feedback-rating').get(getFeedbackRating);
// ------- FEEDBACK ROUTES -----------




// ------- EXPENSE ROUTES -----------
router.route('/add-expense').post(insertExpense);
router.route('/get-expense').get(getExpenses);
router.route('/get-admin-expense').get(getAdminExpenses);
router.route('/update-expense-status/:id').put(updateStatusEx);
router.route('/edit-expense/:id').get(editExpenses);
router.route('/update-expense/:id').put(updateExpenses);
router.route('/delete-expense/:id').delete(deleteExpenses);
router.route('/sum-expense').get(sumExpenses);
router.route('/count-expense').get(countExpenses);
router.route('/avg-expense').get(AvgMonthly);
router.route('/transactions').get(Transactions);
router.route('/get-liner').get(getChartLiner);
// ------- EXPENSE ROUTES -----------


// ------- DISCIPLINARY ROUTES -----------
router.route('/add-disciplinary').post(addDisciplinary);
router.route('/get-disciplinary').get(getDisciplinary);
router.route('/get-disciplinary/:id').get(getDisciplinaryById);
router.route('/update-disciplinary/:id').put(updateDisciplinary);
router.route('/delete-disciplinary/:id').delete(deleteDisciplinary);
router.route('/disciplinary-stats').get(getDisciplinaryStats); 
// ------- DISCIPLINARY ROUTES -----------

// ------- AI ROUTES -----------
// AI functionality is now handled by the enhanced Telegram bot
// ------- AI ROUTES -----------





// ------- PARENT BOT STATISTICS ROUTES -----------
router.route('/parent-bot-stats').get(getParentBotStats);
router.route('/parent-bot-feedback-school/:schoolId').get(getParentBotFeedbackBySchool);
router.route('/parent-bot-realtime-stats').get(getParentBotRealTimeStats);
router.route('/parent-bot-notifications').get(getParentBotNotifications);
// ------- PARENT BOT STATISTICS ROUTES -----------

// ------- PILOT PROGRAM ROUTES -----------
const pilotProgramController = require('../controller/pilotProgramController');

// Pilot Applications
router.route('/pilot-applications').post(pilotProgramController.submitPilotApplication);
router.route('/pilot-applications').get(pilotProgramController.getApplications);
router.route('/pilot-applications/:id/status').put(pilotProgramController.updateApplicationStatus);

// Pilot Programs
router.route('/pilot-programs').post(pilotProgramController.createProgram);
router.route('/pilot-programs').get(pilotProgramController.getPrograms);
router.route('/pilot-programs/school/:schoolId').get(pilotProgramController.getProgramBySchool);
router.route('/pilot-programs/school').get(pilotProgramController.getPilotProgramForSchool);
router.route('/pilot-programs/:id/status').put(pilotProgramController.updateProgramStatus);

// Pilot Payments
router.route('/pilot-programs/:programId/payments').get(pilotProgramController.getProgramPayments);
router.route('/pilot-payments/:id/status').put(pilotProgramController.updatePaymentStatus);
router.route('/pilot-payments').post(pilotProgramController.submitPilotPayment);

// Pilot Milestones
router.route('/pilot-programs/:programId/milestones').get(pilotProgramController.getProgramMilestones);
router.route('/pilot-milestones/:id').put(pilotProgramController.updateMilestone);

// ------- PILOT PROGRAM ROUTES -----------

// ------- REFERRAL SYSTEM ROUTES -----------
// Create referral code for a school
// router.route('/referral/create-code/:schoolId').post(createReferralCode);

// Get referral code for a school
// router.route('/referral/get-code/:schoolId').get(getReferralCode);

// Validate referral code
// router.route('/referral/validate-code').post(validateReferralCode);

// Track referral usage
// router.route('/referral/track-usage').post(trackReferralUsage);

// Get referral analytics for a school
// router.route('/referral/analytics/:schoolId').get(getReferralAnalytics);

// Get all referral analytics (super admin)
// router.route('/referral/analytics').get(getAllReferralAnalytics);

// Get referral tracking records
// router.route('/referral/tracking').get(getReferralTracking);

// Apply referral discount
// router.route('/referral/apply-discount').post(applyReferralDiscount);

// Get referral settings
// router.route('/referral/settings').get(getReferralSettings);

// Update referral settings
// router.route('/referral/settings').put(updateReferralSettings);
// ------- REFERRAL SYSTEM ROUTES -----------

// ------- PERFORMANCE MONITORING ROUTES -----------
// Get system health status
router.route('/performance/health').get(async (req, res) => {
  try {
    const health = await performanceMonitor.getSystemHealth();
    res.status(200).json({
      status: 'success',
      data: health
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get system health',
      error: error.message
    });
  }
});

// Get connection pool status
router.route('/performance/connections').get(async (req, res) => {
  try {
    const connections = await performanceMonitor.getConnectionPoolStatus();
    res.status(200).json({
      status: 'success',
      data: connections
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get connection status',
      error: error.message
    });
  }
});

// Get school capacity statistics
router.route('/performance/capacity').get(async (req, res) => {
  try {
    const capacity = await performanceMonitor.getSchoolCapacityStats();
    res.status(200).json({
      status: 'success',
      data: capacity
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get capacity statistics',
      error: error.message
    });
  }
});

// Get query performance statistics
router.route('/performance/queries').get(async (req, res) => {
  try {
    const queries = await performanceMonitor.getQueryPerformanceStats();
    res.status(200).json({
      status: 'success',
      data: queries
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get query performance',
      error: error.message
    });
  }
});

// ------- REDIS CACHING ROUTES -----------
// Get Redis cache statistics
router.route('/cache/stats').get(async (req, res) => {
  try {
    const stats = await cache.getCacheStats();
    res.status(200).json({
      status: 'success',
      data: stats
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get cache statistics',
      error: error.message
    });
  }
});

// Clear Redis cache
router.route('/cache/clear').post(async (req, res) => {
  try {
    const { school_id } = req.body;
    
    if (school_id) {
      await cache.clearSchoolCache(school_id);
      res.status(200).json({
        status: 'success',
        message: `Cache cleared for school ${school_id}`
      });
    } else {
      await cache.clearAllCache();
      res.status(200).json({
        status: 'success',
        message: 'All cache cleared'
      });
    }
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to clear cache',
      error: error.message
    });
  }
});

// Redis health check
router.route('/cache/health').get(async (req, res) => {
  try {
    const isHealthy = await cache.healthCheck();
    res.status(200).json({
      status: 'success',
      data: {
        healthy: isHealthy,
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Redis health check failed',
      error: error.message
    });
  }
});

// ------- REAL-TIME CACHING ROUTES -----------
// Get real-time dashboard data
router.route('/realtime/dashboard').get(async (req, res) => {
  try {
    const { school_id } = req.query;
    const data = await realTimeCacheService.getDashboardData(school_id);
    
    if (data) {
      res.status(200).json({
        status: 'success',
        data: data
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: 'Real-time data not available'
      });
    }
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get real-time dashboard data',
      error: error.message
    });
  }
});

// Get school-specific real-time data
router.route('/realtime/school/:schoolId').get(async (req, res) => {
  try {
    const { schoolId } = req.params;
    const data = await realTimeCacheService.getSchoolRealTimeData(schoolId);
    
    if (data) {
      res.status(200).json({
        status: 'success',
        data: data
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Real-time data not available for school ${schoolId}`
      });
    }
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get school real-time data',
      error: error.message
    });
  }
});

// Get global real-time data
router.route('/realtime/global').get(async (req, res) => {
  try {
    const data = await realTimeCacheService.getGlobalRealTimeData();
    
    if (data) {
      res.status(200).json({
        status: 'success',
        data: data
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: 'Global real-time data not available'
      });
    }
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get global real-time data',
      error: error.message
    });
  }
});

// Clear real-time cache
router.route('/realtime/clear').post(async (req, res) => {
  try {
    const { school_id } = req.body;
    const cleared = await realTimeCacheService.clearCache(school_id);
    
    if (cleared) {
      res.status(200).json({
        status: 'success',
        message: school_id ? `Real-time cache cleared for school ${school_id}` : 'All real-time cache cleared'
      });
    } else {
      res.status(500).json({
        status: 'error',
        message: 'Failed to clear real-time cache'
      });
    }
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to clear real-time cache',
      error: error.message
    });
  }
});

// Get real-time cache statistics
router.route('/realtime/stats').get(async (req, res) => {
  try {
    const stats = await realTimeCacheService.getCacheStats();
    res.status(200).json({
      status: 'success',
      data: stats
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get real-time cache statistics',
      error: error.message
    });
  }
});

// ------- SESSION MANAGEMENT ROUTES -----------
// Get session statistics
router.route('/sessions/stats').get(sessionStatsMiddleware, async (req, res) => {
  try {
    res.status(200).json({
      status: 'success',
      data: req.sessionStats
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Failed to get session statistics',
      error: error.message
    });
  }
});

// Session health check
router.route('/sessions/health').get(sessionHealthCheck, async (req, res) => {
  try {
    res.status(200).json({
      status: 'success',
      message: 'Session store is healthy',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Session store health check failed',
      error: error.message
    });
  }
});

module.exports = router;